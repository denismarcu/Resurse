package ro.pub.cs.systems.eim.lab04.contactsmanager.general;

public interface Constants {
    final public static int CONTACTS_MANAGER_REQUEST_CODE = 2017;
}
